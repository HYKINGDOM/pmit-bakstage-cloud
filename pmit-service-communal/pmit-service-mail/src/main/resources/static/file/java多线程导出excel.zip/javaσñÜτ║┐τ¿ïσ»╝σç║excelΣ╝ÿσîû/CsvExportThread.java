package com.excel.common.utils.excel;


import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * CSV导出之大量数据-导出压缩包
 */
public class  CsvExportThread extends Thread {

    public static Queue<Object> queue;//Queue是java自己的队列，具体可看API，是同步安全的
    static {
        queue = new ConcurrentLinkedQueue<Object>();
    }
    private static boolean isRunning = false;
    private List<List<Object>> listAll  = new LinkedList<>();
    private int pageNum=0;
    private String filePath;
    private String fileName;
    public CsvExportThread() {
    }

    public CsvExportThread(List<List<Object>> list,int pageNum,String filePath,String fileName) {
        this.listAll = list;
        this.pageNum=pageNum;
        this.filePath=filePath;
        this.fileName=fileName;
    }
    public void run() {
        if (!isRunning) {
            isRunning = true;
            System.out.println("开始执行查询并放入queue队列");
            try {
                CsvExportThread(listAll,pageNum,filePath,fileName);
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
            System.out.println("查询并放入queue队列结束");
            ThreadPools.createThreadPool();//唤起线程池
            isRunning = false;
        } else {
            System.out.println("上一次任务执行还未结束");
        }
    }



    public static synchronized void CsvExportThread(List<List<Object>> listAll,int pageNum,String filePath,String fileName) throws IOException {


        // 设置数据
       // int listCount = 165100;
        int listCount = listAll.size();
        //导出6万以上数据。。。
        int pageSize= pageNum;//设置每一个excel文件导出的数量
        // 设置数据
        int quotient = listCount/pageSize+(listCount%pageSize > 0 ? 1:0);//循环次数
        for(int i=0;i<quotient;i++){
            List<Object> list = new ArrayList<Object>();
            int startCount = ((i> 0 ? i:0)*pageSize);
            if((listCount%pageSize)>0){
                if(i==(quotient-1)){
                    pageSize = (int)(listCount%pageSize);//余数
                }
            }
            list.add(i);
            list.add(startCount+1);
            list.add(pageSize);
            list.add(listAll);
            list.add(filePath);
            list.add(fileName);
            queue.offer(list);
            System.out.println(startCount+"----------------"+pageSize);
        }
//        ZipUtil.zipFiles(srcfile, new File("C:\\cap4j\\download.zip"));
//        ZipUtil.dropFolderOrFile(new File("C:\\cap4j\\download"));
        long endTime = System.currentTimeMillis();
        //分批CSV导出96715
    }

}
