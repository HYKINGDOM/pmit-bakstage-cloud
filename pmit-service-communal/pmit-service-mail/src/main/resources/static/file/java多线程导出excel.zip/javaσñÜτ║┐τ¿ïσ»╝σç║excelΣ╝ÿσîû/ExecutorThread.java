package com.excel.common.utils.excel;

import java.io.File;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;


/*
*线程类实现Runnable接口
*/
public class ExecutorThread implements Runnable {
    private List<Object> obj;

    private int delay;


    public ExecutorThread(List<Object> obj, int delay) {
        //this.objList=objList;
        this.obj=obj;
        this.delay = delay;
    }
    long startTime = System.currentTimeMillis();

    public void run() {
          /*
       *这里就是线程需要处理的业务了，可以换成自己的业务
       */
        try {
            if(obj != null) {
                // 设置表格头
                long startTime = System.currentTimeMillis();
                ResultSetMetaData md = null; //获得结果集结构信息,元数据


                List<List<Object>> objList=(List<List<Object>>)obj.get(3);
                List<List<Object>> dataList = getObjExcel(Integer.parseInt(obj.get(1).toString()),Integer.parseInt(obj.get(2).toString()),objList);
                // 导出文件路径
                String downloadFilePath = obj.get(4).toString();
                // 导出文件名称
                System.out.println("运行的线程数"+Thread.activeCount()+"----------------"+obj.get(0).toString()+"-----------"+obj.get(2).toString());
                String  fileName =obj.get(5).toString()+"_"+obj.get(0).toString();

                // 导出CSV文件
                File csvFile = CSVUtils.createCSVFile(objList.get(0), dataList, downloadFilePath, fileName);
                long endTime = System.currentTimeMillis();
            }
            Thread.sleep(delay);
        } catch (InterruptedException ignored) {
        }
        long endTime = System.currentTimeMillis();
        System.out.println("分批CSV导出"+(endTime-startTime));
    }

    private static List<List<Object>> getObjExcel(int startCount, int pagesize, List<List<Object>>  obj) {

        List<List<Object>> dataList = new ArrayList<List<Object>>();
        int listSize=obj.size();
        for (int i = 0; i < pagesize; i++) {
            int endCount = startCount+i;
            if(endCount<listSize) {
                dataList.add(obj.get(endCount));
            }else{
                break;
            }
        }
        System.gc();
        System.out.println("JVM MAX MEMORY1: " + Runtime.getRuntime().maxMemory()/1024/1024+"M");
        System.out.println("JVM IS USING MEMORY1:" + Runtime.getRuntime().totalMemory()/1024/1024+"M");
        System.out.println("JVM IS FREE MEMORY1:" + Runtime.getRuntime().freeMemory()/1024/1024+"M");
        return dataList;
    }

}
