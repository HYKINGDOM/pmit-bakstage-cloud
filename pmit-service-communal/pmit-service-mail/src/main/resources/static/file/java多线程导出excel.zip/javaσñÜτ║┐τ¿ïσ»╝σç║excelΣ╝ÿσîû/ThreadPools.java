package com.excel.common.utils.excel;

import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;


public class ThreadPools {
    public static void createThreadPool() {
        Random random = new Random();
        final Semaphore semaphore = new Semaphore(10);

        /**
         * 产生一个 ExecutorService 对象，这个对象带有一个大小为 poolSize 的线程池， 若任 务数量大于 poolSize,任务会被放在一个 queue 里顺序执行。这里开启10个线程对象，放入线程池
         */
        ExecutorService executor = Executors.newFixedThreadPool(50);
        int waitTime = 1000;
        try {
            if (CsvExportThread.queue.size() > 0) {
                //这个for循环里的代码就是从线程池里获得线程对象，并执行多线程操作 www.it165.net
                for (int i = 0; i < CsvExportThread.queue.size() + 2; i++) {
                    int time = random.nextInt(1000);
                    waitTime += time;
                    semaphore.acquire();
                    Runnable runner = new ExecutorThread((List<Object>) CsvExportThread.queue.poll(),time);
                    executor.execute(runner);
                    semaphore.release();
                    executor.submit(runner);
                }
            }

          //  System.out.println("已经开启所有的子线程");
            executor.shutdown();
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);

           // System.out.println("shutdown()：启动一次顺序关闭，执行以前提交的任务，但不接受新任务。");
            while(true){
                if(executor.isTerminated()){
             //      System.out.println("所有的子线程都结束了！");
                    break;
                }
                Thread.sleep(1000);
            }

            // 只是将线程池置于关闭状态，不接受新任务，对正在运行的任务不影响MILLISECONDS
           // executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
            // 等待子线程结束，再继续执行下面的代码
           // executor.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}