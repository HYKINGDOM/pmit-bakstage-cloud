package com.excel.common.utils.excel;

import java.io.*;
import java.util.List;

public class CSVUtils {

    /** CSV文件列分隔符 */
    private static final String CSV_COLUMN_SEPARATOR = ",";

    /** CSV文件列分隔符 */
    private static final String CSV_RN = "\r\n";


    /**
     * CSV文件生成方法
     * @param head
     * @param dataList
     * @param outPutPath
     * @param filename
     * @return
     */
    public static File createCSVFile(List<Object> head, List<List<Object>> dataList,String outPutPath, String filename) {
        File csvFile = null;
        BufferedWriter csvWtriter = null;
        try {
            csvFile = new File(outPutPath + File.separator + filename + ".csv");
            File parent = csvFile.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            csvFile.createNewFile();

            // GB2312使正确读取分隔符","
            csvWtriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(csvFile), "GB2312"), 1024);
            // 写入文件头部
            writeRow(head, csvWtriter);

            // 写入文件内容
            for (List<Object> row : dataList) {
                writeRow(row, csvWtriter);
            }
            System.out.println("JVM MAX MEMORY:------------- " + Runtime.getRuntime().maxMemory()/1024/1024+"M");

            System.out.println("JVM IS USING MEMORY:----------" + Runtime.getRuntime().totalMemory()/1024/1024+"M");

            System.out.println("JVM IS FREE MEMORY:----------" + Runtime.getRuntime().freeMemory()/1024/1024+"M");
            csvWtriter.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                csvWtriter.close();
                System.gc();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return csvFile;
    }

//
//    public static void CsvExportThread(List<Map<String, Object>> listMap, int pageNum, String filePath, String fileName){
//        Thread cvs= new CsvExportThread(listMap,500000,filePath,fileName);
//        cvs.start();
//    }

    /**
     * 写一行数据方法
     * @param row
     * @param csvWriter
     * @throws IOException
     */
    private static void writeRow(List<Object> row, BufferedWriter csvWriter) throws IOException {
        // 写入文件头部
        for (Object data : row) {
            StringBuffer buf = new StringBuffer();
            String rowStr =  buf.append("\"").append(data).append("\t\",").toString();
            csvWriter.write(rowStr);
        }
        csvWriter.newLine();
    }
}