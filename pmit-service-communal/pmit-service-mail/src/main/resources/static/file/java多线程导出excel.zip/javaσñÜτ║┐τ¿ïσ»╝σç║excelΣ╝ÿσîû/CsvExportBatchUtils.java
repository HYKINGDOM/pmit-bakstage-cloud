package com.excel.common.utils.excel;

import java.io.File;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * CSV导出之大量数据-导出压缩包
 * 
 */
public class CsvExportBatchUtils {

    public static void getExportExcel(List<Map<String, Object>> list) {
        long startTime = System.currentTimeMillis();
        ResultSetMetaData md = null; //获得结果集结构信息,元数据
        List<Object> headList = new ArrayList<>();

        headList.add("序号");
        // 设置数据
        int listCount = list.size();
        for (Map.Entry<String, Object> entry : list.get(0).entrySet()) {
            //表头
            headList.add(entry.getKey());
        }

        //导出6万以上数据。。。
        int pageSize= 50000;//设置每一个excel文件导出的数量
        int quotient = listCount/pageSize+(listCount%pageSize > 0 ? 1:0);//循环次数
        List<File> srcfile=new ArrayList<File>();
        for(int i=0;i<quotient;i++){
            int startCount = ((i> 0 ? i:0)*pageSize);
            if((listCount%pageSize)>0){
                if(i==(quotient-1)){
                    pageSize = (int)(listCount%pageSize);//余数
                }
            }
            List<List<Object>> dataList = getObjExcel(startCount, pageSize,list);
            // 导出文件路径
            String downloadFilePath = "C:" + File.separator + "cap4j" + File.separator + "download"+File.separator;
            // 导出文件名称
            String  fileName = String.valueOf(i);
            // 导出CSV文件
            File csvFile = CSVUtils.createCSVFile(headList, dataList, downloadFilePath, fileName);
            srcfile.add(csvFile);
        }
        long endTime = System.currentTimeMillis();
        System.out.println("分批CSV导出"+(endTime-startTime));
    }
    private static List<List<Object>> getObjExcel(int startCount, int pagesize, List<Map<String, Object>> list) {

        List<List<Object>> dataList = new ArrayList<List<Object>>();
        List<Object> rowList = null;
        for (int i = 0; i < pagesize; i++) {
            rowList = new ArrayList<Object>();
            Object[] row = new Object[list.get(i).entrySet().size()+1];
            int endCount = startCount+i;
            row[0] = endCount+1;
            int num=0;
            for (Map.Entry<String, Object> entry : list.get(endCount).entrySet()) {
                num++;
                row[num]=entry.getValue();
            }
            for(int j=0;j<row.length;j++){
                rowList.add(row[j]);
            }
            dataList.add(rowList);
        }
        return dataList;
    }
}
